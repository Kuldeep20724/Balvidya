function loadPage(pageName) {
  $("#main-content").html('<div class="text-center my-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div><p>Loading ' + pageName + '...</p></div>');

  $.ajax({
    url: `pages/${pageName}.html`,
    method: 'GET',
    success: function(data) {
      $("#main-content").html(data);
    },
    error: function() {
      $("#main-content").html("<p class='text-danger'>Sorry! Couldn't load the page.</p>");
    }
  });
}
